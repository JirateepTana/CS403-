

import sqlite3
from tkinter import messagebox
from tkinter import *

def createconnection() :
    global conn,cursor
    conn = sqlite3.connect('database/User.db')
    cursor = conn.cursor()

def mainwindow() :
    root = Tk()
    w = 1000
    h = 600
    x = root.winfo_screenwidth()/2 - w/2
    y = root.winfo_screenheight()/2 - h/2
    root.geometry("%dx%d+%d+%d"%(w,h,x,y))
    root.config(bg='#8ac4d0')
    #root.config(bg='#4a3933')
    root.title("Login/Register Application: ")
    root.option_add('*font',"Garamond 24 bold")
    root.rowconfigure((0,1,2,3),weight=1)
    root.columnconfigure((0,1,2,3),weight=1)
    return root

def loginlayout() :
    global userentry,pwdentry,loginframe
    userinfo = StringVar()
    pwdinfo = StringVar()
    loginframe = Frame(root,bg='#085E7D')
    loginframe.rowconfigure((0,1,2,3),weight=1)
    loginframe.columnconfigure((0,1),weight=1)
    
    Label(loginframe,text="Login/Register Application",font="Garamond 26 bold",compound=LEFT,bg='#085E7D',fg='#e4fbff').grid(row=0,columnspan=2)
    Label(loginframe,text="Username : ",bg='#085E7D',fg='#e4fbff',padx=20).grid(row=1,column=0,sticky='e')
    userentry = Entry(loginframe,bg='#e4fbff',width=20,textvariable=userinfo)
    userentry.grid(row=1,column=1,sticky='w',padx=20)
    pwdentry = Entry(loginframe,bg='#e4fbff',width=20,show='*',textvariable=pwdinfo)
    pwdentry.grid(row=2,column=1,sticky='w',padx=20)
    Label(loginframe,text="Password  : ",bg='#085E7D',fg='#e4fbff',padx=20).grid(row=2,column=0,sticky='e')
    Button(loginframe,text="Login",width=10,command=lambda:loginclick(userinfo.get(),pwdinfo.get())).grid(row=3,column=1,pady=20,ipady=15,sticky='e',padx=20)
    Button(loginframe,text="Register",width=10,command=regislayout).grid(row=3,column=1,pady=20,ipady=15,sticky='w',padx=20)
    loginframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')

def loginclick(user,pwd) :
    #global result
    if user == "" or pwd == "" :
        messagebox.showwarning("Admin:","Please enter a username and password.")
        userentry.focus_force()
    else :
        sql = "select * from login where user=?"
        cursor.execute(sql,[user])
        result = cursor.fetchall()
        if result :
            sql = "select * from login where user=? and pwd=? "
            cursor.execute(sql,[user,pwd])   #case1
            result = cursor.fetchone()
            if result :
                messagebox.showinfo("Admin:","Login Successfully")
                loginframe.grid_forget()
                welcomepage(result)
            else :
                messagebox.showwarning("Admin:","Incorrect Password")
                pwdentry.select_range(0,END)
                pwdentry.focus_force()
        else :
            messagebox.showerror("Admin:","The username not found\n Please register before Login")
            userentry.select_range(0,END)
            userentry.focus_force()

def regislayout() :
    global fullname,lastname,newuser,newpwd,cfpwd
    root.title("Welcome to User Registration : ")
    root.config(bg='lightblue')
    regisframe = Frame(root,bg='#8ac4d0')
    regisframe.rowconfigure((0,1,2,3,4,5,6),weight=1)
    regisframe.columnconfigure((0,1),weight=1)
    Label(regisframe,text="Registration Form",font="Garamond 26 bold",fg='#e4fbff',compound=LEFT,bg='#1687a7').grid(row=0,column=0,columnspan=2,sticky='news',pady=10)
    Label(regisframe,text='Full name : ',bg='#8ac4d0',fg='#f6f5f5').grid(row=1,column=0,sticky='e',padx=10)
    fullname = Entry(regisframe,width=20,bg='#d3e0ea')
    fullname.grid(row=1,column=1,sticky='w',padx=10)
    Label(regisframe,text='Last name : ',bg='#8ac4d0',fg='#f6f5f5').grid(row=2,column=0,sticky='e',padx=10)
    lastname = Entry(regisframe,width=20,bg='#d3e0ea')
    lastname.grid(row=2,column=1,sticky='w',padx=10)
    Label(regisframe,text="Username : ",bg='#8ac4d0',fg='#f6f5f5').grid(row=3,column=0,sticky='e',padx=10)
    newuser = Entry(regisframe,width=20,bg='#d3e0ea')
    newuser.grid(row=3,column=1,sticky='w',padx=10)
    Label(regisframe,text="Password : ",bg='#8ac4d0',fg='#f6f5f5').grid(row=4,column=0,sticky='e',padx=10)
    newpwd = Entry(regisframe,width=20,bg='#a1cae2',show='*')
    newpwd.grid(row=4,column=1,sticky='w',padx=10)
    Label(regisframe,text="Confirm Password : ",bg='#8ac4d0',fg='#f6f5f5').grid(row=5,column=0,sticky='e',padx=10)
    cfpwd = Entry(regisframe,width=20,bg='#a1cae2',show='*')
    cfpwd.grid(row=5,column=1,sticky='w',padx=10)
    regisaction = Button(regisframe,text="Register Submit",command=registration)
    regisaction.grid(row=6,column=1,ipady=5,ipadx=5,pady=5,sticky='w')
    fullname.focus_force()
    loginbtn = Button(regisframe,text="Back to Login",command=loginlayout)
    loginbtn.grid(row=6,column=0,ipady=5,ipadx=5,pady=5,sticky='e',padx=10)
    regisframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')

def registration() :
    #print("Hello from registration")
    if fullname.get() == "" :
        messagebox.showwarning("Admin: ","Please enter a firstname")
        fullname.focus_force()
    elif lastname.get() == "" :
        messagebox.showwarning("Admin : ", "Please enter a lastname")
        lastname.focus_force()
    elif newuser.get() == "" :
        messagebox.showwarning("Admin : ", "Please enter a username")
        newuser.focus_force()
    elif newpwd.get() == "" :
        messagebox.showwarning("Admin : ", "Please enter a password")
        newpwd.focus_force()
    elif cfpwd.get() == "" :
        messagebox.showwarning("Admin : ", "Please enter a comfirm password")
        cfpwd.focus_force()
    else : # check a username is already exist???
        sql = "select * from login where user=?;"
        #execute sql query
        cursor.execute(sql,[newuser.get()])
        result = cursor.fetchone() #fetch a result
        if result :
            messagebox.showerror("Admin:","The username is already exists \n Try again") #usernameซ้ำ
            newuser.select_range(0,END)
            newuser.focus_force()
        else :
            if newpwd.get() == cfpwd.get() : #verify a new pwd and confirm pwd are equal
                sql = "insert into login values (?,?,?,?);" #insert into statement
                #execute sql query 
                cursor.execute(sql,[newuser.get(), newpwd.get(), fullname.get(),lastname.get()])
                conn.commit()
                retrivedata()
                messagebox.showinfo("Admin:","Registration Successfully")
                resetdata()                
            else :  #verify a new pwd and confirm pwd are not equal
                messagebox.showwarning("Admin: ","Incorrect a confirm password\n Try again")
                cfpwd.select_range(0,END)
                cfpwd.focus_force()

def retrivedata() :
    sql = "select * from login"
    cursor.execute(sql)
    result = cursor.fetchall()
    print("Total row = ",len(result))
    for i,data in enumerate(result) :
        print("Row#",i+1,data)

def welcomepage(result) :
    Label(root,text="Welcome to Main Page",fg='#534340',bg='#8ac4d0',font='Mali 32 bold').grid(row=0,columnspan=4)
    welcomeframe = Frame(root,bg='#085E7D')
    welcomeframe.rowconfigure((0,1,2,3),weight=1)
    welcomeframe.columnconfigure((0,1),weight=1)
    Label(welcomeframe,text="Welcome : "+result[2]+" "+result[3],bg='#085E7D',image=img1,compound=LEFT,fg='white').grid(row=0,columnspan=2)
    welcomeframe.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='news')
    Button(welcomeframe,text="Exit",width=10,height=1,command=root.quit).grid(row=4,column=1,pady=10,padx=15,sticky=E)

def resetdata() :
    fullname.delete(0,END)
    lastname.delete(0,END)
    newuser.delete(0,END)
    newpwd.delete(0,END)
    cfpwd.delete(0,END)

createconnection()
root = mainwindow()
img1 = PhotoImage(file='images/profile.png').subsample(5,5)
loginlayout()
root.mainloop()
cursor.close()
conn.close()